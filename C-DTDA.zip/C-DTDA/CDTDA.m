classdef CDTDA < ALGORITHM 
% <multi> <real/integer/label/binary/permutation> <constrained>
% type --- 1 --- Type of operator (1. DE 2. GA)

%------------------------------- Copyright --------------------------------
% Copyright (c) 2023 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB Platform
% for Evolutionary Multi-Objective Optimization [Educational Forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------
%by Xiaowei Wei 
   methods
       function main(Algorithm,Problem)
           type = Algorithm.ParameterSet(1);

           %% Generate the weight vectors
           [W,Problem.N] = UniformPoint(Problem.N,Problem.M);
           
           %% Generate random population
           Population1 = Problem.Initialization();      %PopMain
           Population2 = Problem.Initialization();      %PopAux1
           Population3 = Population2;                   %PopAux2
           Fitness1    = CalFitness(Population1.objs,Population1.cons,0);
           Fitness2    = CalFitness(Population2.objs,Population2.cons,1e6);

           change_threshold = 1e-3;             
           max_change       = 1;                
           epsilon_k        = 1e8;
           gen              = 1;
           stage            = 1;
           Objvalues(gen) = sum(sum(Population2.objs,1));
 
           Ideal = zeros(ceil(Problem.maxFE/Problem.N),Problem.M);
           Ideal(1,:) = min(Population2.objs,[],1);

           %% Optimization
           while Algorithm.NotTerminated(Population1) 
               %Single traction stage
               if stage == 1
                   % randomly selection
                    if type == 1
                         Offspring1  = OperatorDE(Problem,Population1,Population1(randi(Problem.N,1,Problem.N)),Population1(randi(Problem.N,1,Problem.N))); 
                         Offspring2  = OperatorDE(Problem,Population2,Population2(randi(Problem.N,1,Problem.N)),Population2(randi(Problem.N,1,Problem.N))); 
                    elseif type == 2
                         Offspring1  = OperatorGAhalf(Problem,Population1(randi(Problem.N,1,Problem.N)));
                         Offspring2  = OperatorGAhalf(Problem,Population2(randi(Problem.N,1,Problem.N)));
                    end 

                    [Population1,Fitness1] = EnvironmentalSelection([Population1,Offspring1,Offspring2],Problem.N,true,0);         
                    [Population2,Fitness2] = EnvironmentalSelection([Population2,Offspring1,Offspring2],Problem.N,false,epsilon_k);     

                    Ideal(ceil(Problem.FE/Problem.N),:) = min(Population2.objs,[],1);
                    gen = gen+1;
                    pop_cons2      = Population2.cons;
                    cv2            = overall_cv(pop_cons2);
                    population     = [Population2.decs,Population2.objs,cv2];
                    Objvalues(gen) = sum(sum(Population2.objs,1));

                    %Determining stage transitions
                    [FrontNo2,~] = NDSort(Population2.objs,size(Population2.objs,1));
                    NC2 = size(find(FrontNo2==1),2);
                    if gen > 10
                        max_change = abs(Objvalues(gen)-Objvalues(gen-1));
                    end               
                    if (max_change <= change_threshold &&NC2 == Problem.N) || Problem.FE/Problem.maxFE > 0.3
                        epsilon_k = max(population(:,end),[],1);
                        max_epsilon = epsilon_k;
                        stage = 2;
                        Population3 = Population2;
                        ZPop = [Population1,Population2];
                        Z = min(ZPop.objs,[],1);        %The ideal point of the current generation population during stage transitions
                        FE_switch = Problem.FE; 
                    end

                %Dual traction stage
                else
                        if type == 1
                            MatingPool1 = TournamentSelection(2,2*Problem.N,Fitness1);
                            Offspring1  = OperatorDE(Problem,Population1,Population1(MatingPool1(1:end/2)),Population1(MatingPool1(end/2+1:end)));
                            Offspring2  = OperatorDE(Problem,Population2,Population2(randi(Problem.N,1,Problem.N)),Population2(randi(Problem.N,1,Problem.N)));
                        elseif type == 2
                            MatingPool1 = TournamentSelection(2,Problem.N,Fitness1);
                            Offspring1  = OperatorGAhalf(Problem,Population1(MatingPool1));
                            Offspring2  = OperatorGAhalf(Problem,Population2(randi(Problem.N,1,Problem.N)));
                        end 

                        Fitness3    = CalFitness(Population3.objs,Population3.cons,0);
                        runtime = (Problem.FE-FE_switch)/(Problem.maxFE-FE_switch);

                        %Dynamic search attention strategy
                        Offspring3 = Operator_Dis(Problem, Population3, Fitness3, runtime, type);
                        
                        %improved epsilon constraint method
                        if epsilon_k < 1e-6
                            epsilon_k = 0;
                        else
                            epsilon_k =  update_epsilon(Problem,max_epsilon, Population2,FE_switch);
                        end

                        [Population1,Fitness1] = EnvironmentalSelection([Population1,Offspring1,Offspring2,Offspring3],Problem.N,true,0);
                        [Population2,Fitness2] = EnvironmentalSelection([Population2,Offspring1,Offspring2,Offspring3],Problem.N,false,epsilon_k);

                        ZPop = [Population1,Population2];
                        Z = min(ZPop.objs,[],1);
                        P_sec_combine = [Population3,Offspring1,Offspring2,Offspring3];   
                        
                        %Environmental selection of Population 3：
                        CV1 = sum(max(0,Population1.cons),2);
                        [~,Region] = min(pdist2(P_sec_combine.objs-repmat(Z,length(P_sec_combine),1),W,'cosine'),[],2);     %Individuals in P_sec_combine are associated with weight vectors.
                        [~,Region_M] = min(pdist2(Population1.objs-repmat(Z,length(Population1),1),W,'cosine'),[],2);   %Individuals in PopMain are associated with weight vectors.
                        
                        %Adaptive diversity expansion strategy
                        for i = 1:Problem.N
                            index = find(Region_M==i);
                            if(isempty(index))
                                 [~,nearIdx] = min(pdist2(W(i,:),Population1.objs-repmat(Z,length(Population1),1),'cosine'),[],2);
                                 refpoint = Population1(nearIdx);
                                 OffIndex = Region==i;
                                 Candidate = P_sec_combine(OffIndex);
                                 if (isempty(Candidate))
                                     Population3(i) = refpoint;
                                 else
                                     CV_can = sum(max(0,Candidate.cons),2);
                                     index_cv = CV_can==min(CV_can);
                                     Pop_Temp = Candidate(index_cv);
                                     g = max(abs(Pop_Temp.objs-repmat(Z,length(Pop_Temp),1))./W(i,:),[],2);
                                     index3 = find(g==min(g),1);
                                     Population3(i) = Pop_Temp(index3);
                                 end
                            else
                                index2 = CV1(index)==min(CV1(index));
                                Pop_Temp = Population1(index(index2));
                                g = max(abs(Pop_Temp.objs-repmat(Z,length(Pop_Temp),1))./W(i,:),[],2);
                                index3 = find(g==min(g),1);
                                Population3(i) = Pop_Temp(index3);
                            end
                        end
               end
           end
       end
   end
end

function result = overall_cv(cv)
    cv(cv <= 0) = 0;cv = abs(cv);
    result = sum(cv,2);
end

function   result = update_epsilon(Problem,max_epsilon,Population2,FE_switch)
    result = max_epsilon*(2 - 2 / (1 + exp(-20*(Problem.FE-FE_switch)/(Problem.maxFE-FE_switch))))*(1-Feasible_rate(Population2));
end
