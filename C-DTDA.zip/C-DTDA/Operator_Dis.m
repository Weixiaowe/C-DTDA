function  [ offspring ] = Operator_Dis(Problem, Population, Fitness, runtime, type)

%------------------------------- Copyright --------------------------------
% Copyright (c) 2023 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

%by Xiaowei Wei 
%Dynamic search attention strategy

    offspring = [];
  
    num = floor(runtime * Problem.N);
    Mat = TournamentSelection(2,num,Fitness);
    MatingPool(1:num) = Population(Mat);
    if num < Problem.N
        randmat = randperm(Problem.N, Problem.N-num);
        MatingPool(num+1:Problem.N) = Population(randmat);      
    end

    for i = 1:Problem.N
        Parent1 = MatingPool(i);

        distances = sqrt(sum((MatingPool.objs - Parent1.objs).^2, 2));
        [sortedDistances, sortedIdx] = sort(distances);     
        if (Problem.FE/Problem.maxFE) < 0.7
            Co_dis = floor((1-runtime) * Problem.N/2);        
        else
            Co_dis = 6;
        end

        if type == 2
            randco = randi([2, Co_dis]);   
            Parent2 = MatingPool(sortedIdx(randco));
            offspring_new = OperatorGAhalf(Problem,[Parent1,Parent2]);
        else
            randco = randperm(Co_dis - 1) + 1;
            Parent2 = MatingPool(sortedIdx(randco(1)));
            Parent3 = MatingPool(sortedIdx(randco(2)));
            offspring_new = OperatorDE(Problem, Parent1, Parent2, Parent3);
        end
        offspring = [offspring,offspring_new];
    end
end